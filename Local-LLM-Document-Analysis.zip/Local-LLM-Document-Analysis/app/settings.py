import os
from dotenv import load_dotenv

load_dotenv()

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "").strip()
OPENAI_EMBED_MODEL = os.getenv("OPENAI_EMBED_MODEL", "text-embedding-3-large")
OPENAI_CHAT_MODEL = os.getenv("OPENAI_CHAT_MODEL", "gpt-4o-mini")

DATA_RAW = "data/raw"
DB_DIR = "data/processed/faiss"
CHUNK_SIZE = 1000
CHUNK_OVERLAP = 150
SEARCH_K = 5
