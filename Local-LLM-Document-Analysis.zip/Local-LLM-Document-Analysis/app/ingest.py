
import os, pathlib
from bs4 import BeautifulSoup
from dotenv import load_dotenv
from app.settings import DATA_RAW, DB_DIR, CHUNK_SIZE, CHUNK_OVERLAP, OPENAI_API_KEY, OPENAI_EMBED_MODEL
from langchain_community.document_loaders import PyPDFLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import FAISS

def get_embeddings():
    """Use local MiniLM sentence-transformer embeddings."""
    from sentence_transformers import SentenceTransformer

    model = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")

    class LocalEmb:
        def embed_documents(self, texts):
            # already returns a list — no need for .tolist()
            return model.encode(texts, convert_to_numpy=True).tolist()

        def embed_query(self, text):
            # single query version
            return model.encode([text], convert_to_numpy=True)[0].tolist()

    return LocalEmb()

def load_docs():
    docs = []
    for p in pathlib.Path(DATA_RAW).glob("*"):
        if p.suffix.lower() == ".pdf":
            pages = PyPDFLoader(str(p)).load()
            for d in pages:
                d.metadata["source"] = f"{p.name}#p{d.metadata.get('page','')}"
            docs.extend(pages)
        elif p.suffix.lower() in [".htm", ".html", ".xml"]:
            with open(p, "r", encoding="utf-8", errors="ignore") as f:
                soup = BeautifulSoup(f, "html.parser")
                text = soup.get_text(separator=" \n", strip=True)
            from langchain.schema import Document
            docs.append(Document(page_content=text, metadata={"source": p.name}))
    return docs

def main():
    load_dotenv()
    os.makedirs(DB_DIR, exist_ok=True)
    docs = load_docs()
    if not docs:
        print(f"No files found in {DATA_RAW}. Add 10-K HTML or PDF files and rerun.")
        return
    splitter = RecursiveCharacterTextSplitter(chunk_size=CHUNK_SIZE, chunk_overlap=CHUNK_OVERLAP)
    chunks = splitter.split_documents(docs)
    embeddings = get_embeddings()
    vs = FAISS.from_documents(chunks, embeddings)
    vs.save_local(DB_DIR)
    print(f"Indexed {len(chunks)} chunks -> {DB_DIR}")

if __name__ == "__main__":
    main()
