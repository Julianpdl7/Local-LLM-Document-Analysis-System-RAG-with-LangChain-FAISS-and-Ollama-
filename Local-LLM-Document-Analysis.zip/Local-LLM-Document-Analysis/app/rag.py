
import os
from dotenv import load_dotenv
from app.settings import DB_DIR, OPENAI_API_KEY, OPENAI_EMBED_MODEL, OPENAI_CHAT_MODEL, SEARCH_K
from langchain_community.vectorstores import FAISS
from langchain.prompts import ChatPromptTemplate
from langchain.schema.runnable import RunnablePassthrough

def _local_emb():
    from sentence_transformers import SentenceTransformer
    model = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")
    class E:
        def embed_documents(self, t): return model.encode(t, convert_to_numpy=False).tolist()
        def embed_query(self, t): return model.encode(t, convert_to_numpy=False).tolist()
    return E()


def get_retriever():
    if OPENAI_API_KEY:
        from langchain_openai import OpenAIEmbeddings
        emb = OpenAIEmbeddings(model=OPENAI_EMBED_MODEL)
    else:
        # Use the official wrapper so FAISS expects the right interface
        from langchain_community.embeddings import HuggingFaceEmbeddings
        emb = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")
    vs = FAISS.load_local(DB_DIR, emb, allow_dangerous_deserialization=True)
    return vs.as_retriever(search_type="mmr", search_kwargs={"k": SEARCH_K})

SYSTEM = '''You are a precise financial-reporting assistant.
Answer using ONLY the provided context. If unsure, say "I don't know."
Cite sources as [filename#pX] where X is the page number or section.
'''

PROMPT = ChatPromptTemplate.from_messages([
    ("system", SYSTEM),
    ("human", "Q: {question}\n\nContext:\n{context}\n\nAnswer with citations.")
])

def build_chain():
    load_dotenv()
    if OPENAI_API_KEY:
        from langchain_openai import ChatOpenAI
        llm = ChatOpenAI(model=OPENAI_CHAT_MODEL, temperature=0)
    else:
        from langchain_community.chat_models import ChatOllama
        llm = ChatOllama(model="llama3.1:8b", temperature=0)

    retriever = get_retriever()

    def format_docs(docs):
        return "\n\n".join(
            f"[{d.metadata.get('source','?')}] {d.page_content[:1500]}"
            for d in docs
        )

    chain = (
        {"context": retriever | format_docs, "question": RunnablePassthrough()}
        | PROMPT
        | llm
    )
    return chain
